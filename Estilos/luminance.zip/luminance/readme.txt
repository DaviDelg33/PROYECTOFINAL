This template / effect / code has been created by Franklin Castellanos.
You can customize and check it out on its original site on the following link:
https://codepen.io/onecastell/pen/VwZWBvr

Thank you